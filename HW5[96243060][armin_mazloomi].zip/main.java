import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Scanner;

class main{
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Position[][] map = getMap();
        ArrayList<Person> listOfPersons = new ArrayList<>();
        ArrayList<Tools> listOfTools = new ArrayList<>();
        Target target = new Target();
        setPlaceDetails(map, listOfPersons, listOfTools);
        Hitman hitman = (Hitman)getHitman(listOfPersons);
        getTargets(map, target);
        while (!end(target, hitman)) {
            getOrder(map, listOfPersons, listOfTools, hitman, target);
        }
    }

    static void getOrder(Position[][] map, ArrayList<Person> listOfPersons, ArrayList<Tools> listOfTools, Hitman hitman, Target target){
        Scanner input = new Scanner(System.in);
        String order = input.nextLine();
        switch (order.length()){
            case (8):
                showMap(map);
                break;
            case(6):
                showPlaceDetails(map, order, listOfPersons, listOfTools, target);
                break;
            case(4):
                hitman.hitmanMove(map);
                completeHitmanMove(map, listOfPersons, listOfTools, hitman, target);
                update(map, listOfPersons, listOfTools, hitman);
                break;
                default:
                    System.out.println("Invalid Command.");
        }
    }

    static void completeHitmanMove(Position[][] map, ArrayList<Person> listOfPersons, ArrayList<Tools> listOfTools, Hitman hitman, Target target){
        Iterator<Tools> itrTools = listOfTools.iterator();
        while(itrTools.hasNext()){
            Tools tool = (Tools) itrTools.next();
            if(tool.place == hitman.place){
                if(tool instanceof Stone){
                    ((Stone) tool).throwStone(map);
                }else if(tool instanceof Snipe){
                    ((Snipe) tool).shoot(listOfPersons, hitman);
                }else if(tool instanceof Pot){//Not correct in unhidding
                    ((Pot) tool).hidingInpot(hitman);
                }else if(tool instanceof Camera){

                }else{

                }
            }
        }
        hitman.kill(listOfPersons);
        target.win(hitman);
    }

    static void update(Position[][] map, ArrayList<Person> listOfPersons, ArrayList<Tools> listOfTools, Hitman hitman){
        Iterator<Person> itrPersons = listOfPersons.iterator();
        while(itrPersons.hasNext()){
            Person person = (Person) itrPersons.next();

            if(person instanceof Enemy){
                ((Enemy) person).kill(hitman, map);
            }
            if(person instanceof DynamicEnemy){
                ((DynamicEnemy) person).move(map);
            }
            if(person instanceof SpinicEnemy){
                ((SpinicEnemy) person).changeDirection();
            }

        }
    }

    static boolean end(Target target, Hitman hitman){
        if(target.done){
            System.out.println("Level Complete");
            System.out.println(hitman.numberOfMoves + " Moves");
            return true;
        }
        if(!hitman.alive){
            System.out.println("You've Lost");
            System.out.println(hitman.numberOfMoves + " Moves");
        }
        return !(hitman.alive);
    }

    static Person getHitman(ArrayList<Person> listOfPersons){
        Iterator<Person> itr = listOfPersons.iterator();
        while(itr.hasNext()){
            Person person = (Person)itr.next();
            if(person instanceof Hitman){
                return person;
            }
        }
        return null;
    }

    static void showPlaceDetails(Position[][] map, String row, ArrayList<Person> listOfPersons, ArrayList<Tools> listOfTools, Target target){
        row = row.replace("Show ", "");
        char place = row.charAt(0);
        Iterator<Person> itrPersons = listOfPersons.iterator();
        while(itrPersons.hasNext()){
            Person person = (Person) itrPersons.next();
            if(person.place.name == place && person.alive){
                if(person instanceof Hitman){
                    System.out.println("Hitman");
                }else if(person instanceof StaticEnemy){
                    System.out.println("Static Enemy Looking " + person.direction);
                }else if(person instanceof DynamicEnemy){
                    System.out.println("Dynamic Enemy Looking " + person.direction);
                }else if(person instanceof SmellicEnemy){
                    System.out.println("Smellic Enemy Looking " + person.direction);
                }else if(person instanceof SpinicEnemy){
                    System.out.println("Spinic Enemy Looking " + person.direction);
                }
            }
        }
        Iterator<Tools> itrTools = listOfTools.iterator();
        while(itrTools.hasNext()){
            Tools tools = (Tools) itrTools.next();
            if(tools.place.name == place){
                if(tools instanceof Stone){
                    System.out.println("Stone");
                }else if(tools instanceof Snipe){
                    System.out.println("Snipe");
                }else if(tools instanceof Camera){
                    System.out.println("Camera");
                }else if(tools instanceof TelePort){
                    System.out.println("TelePort");
                }else if(tools instanceof Pot){
                    System.out.println("Pot");
                }
            }
        }
        if(place == target.place.name){
            System.out.println("Target");
        }
    }

    static void getTargets(Position[][] map, Target target){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the target:");
        String targetString = input.nextLine();
        target.place = getHouseLable(map, targetString.charAt(7));
    }
    static void showMap(Position[][] map){
        for(int i = 0; i < map.length; i++){
            for(int j = 0; j < map[0].length; j++){
                System.out.print(map[i][j].name);
                if(map[i][j].right){
                    System.out.print("-");
                }else{
                    System.out.print(" ");
                }
            }
            System.out.println();
            for(int k = 0; k < map[0].length * 2; k++){
                if(k % 2 == 0){
                    if(map[i][k / 2].down){
                        System.out.print("|");
                    }else{
                        System.out.print(" ");
                    }
                }else{
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
    static void setPlaceDetails(Position[][]map, ArrayList<Person> listOfPersons, ArrayList<Tools> listOfTools){
        Scanner input = new Scanner(System.in);
        for(int counter = 0; counter < map.length * map[0].length; counter++) {
            String detailsOfPlace = input.nextLine();
            Position place = new Position();
            place = getHouseLable(map, detailsOfPlace.charAt(1));
            detailsOfPlace = detailsOfPlace.replace(detailsOfPlace.substring(0, 3), "");
            String detailsOfPersons = detailsOfPlace.substring(0, detailsOfPlace.indexOf('$') + 1);
            String detailsOfTools = detailsOfPlace.substring(detailsOfPlace.indexOf('$'), detailsOfPlace.indexOf('}') + 1);

            //Filling person arraylist
            while (detailsOfPersons.charAt(0) != '$') {
                Person person = new Person(place);
                person = getPerson(detailsOfPersons, place);
                detailsOfPersons = detailsOfPersons.replaceFirst(detailsOfPersons.substring(0, detailsOfPersons.indexOf('@') + 1), "");
                setDirection(detailsOfPersons, person);
                if (detailsOfPersons.indexOf(',') >= 0) {
                    detailsOfPersons = detailsOfPersons.replaceFirst(detailsOfPersons.substring(0, detailsOfPersons.indexOf(',')), "");
                } else {
                    detailsOfPersons = detailsOfPersons.replaceFirst(detailsOfPersons.substring(0, detailsOfPersons.indexOf('$')), "");
                }
                listOfPersons.add(person);
            }
            detailsOfTools = detailsOfTools.replace("$", "");

            //Filling tools arraylist
            while (detailsOfTools.charAt(0) != '}') {
                Tools tool = new Tools(place);
                tool = getTool(detailsOfTools, place);
                if (detailsOfTools.indexOf(',') >= 0) {
                    detailsOfTools = detailsOfTools.replaceFirst(detailsOfTools.substring(0, detailsOfTools.indexOf(',') + 1), "");
                } else {
                    detailsOfTools = detailsOfTools.replaceFirst(detailsOfTools.substring(0, detailsOfTools.indexOf('}')), "");
                }
                listOfTools.add(tool);
            }
        }
    }

    static Person getPerson(String row, Position place){
        String temp;
        if(row.charAt(0) == ',') {
            temp = row.substring(1, row.indexOf('@'));
        }else{
            temp = row.substring(0, row.indexOf('@'));
        }
        if(temp.equals("Hitman")){
            Person person = new Hitman(place);
            return person;
        }else if(temp.equals("Static Enemy")){
            Person person = new StaticEnemy(place);
            return person;
        }else if(temp.equals("Dynamic Enemy")){
            Person person = new DynamicEnemy(place);
            return person;
        }else if(temp.equals("Spinic Enemy")){
            Person person = new SpinicEnemy(place);
            return person;
        }else if(temp.equals("Smellic Enemy")){
            Person person = new SmellicEnemy(place);
            return person;
        }else{
            return null;
        }
    }

    static Tools getTool(String row, Position place){
        String temp;
        if(row.charAt(0) == ','){
            temp = row.substring(1, row.indexOf('}'));
        }else{
            temp = row.substring(0, row.indexOf('}'));
        }

        if(temp.equals("Stone")){
            Tools tool = new Stone(place);
            return tool;
        }else if(temp.equals("Snipe")){
            Tools tool = new Snipe(place);
            return tool;
        }else if(temp.equals("Teleport")){
            Tools tool = new TelePort(place);
            return tool;
        }else if(temp.equals("Camera")){
            Tools tool = new Camera(place);
            return tool;
        }else if(temp.equals("Pot")){
            Tools tool = new Pot(place);
            return tool;
        }else{
            return null;
        }
    }

    static void setDirection(String row, Person person){
        if(row.indexOf(',') >= 0) {
            person.direction = row.substring(0, row.indexOf(','));
        }else{
            person.direction = row.substring(0, row.indexOf('$'));
        }
    }

    static Position getHouseLable(Position[][] map, char name){
        for(int i = 0; i < map.length; i++){
            for(int j = 0; j < map[i].length; j++){
                if(map[i][j].name == name){
                    return map[i][j];
                }
            }
        }
        return null;
    }


    static void polishRow(Position[][] map, String row, int rowNumber) {
        for(int counter = 0; counter < map[rowNumber].length * 2 - 1; counter++){
            if(counter % 2 == 0){
                map[rowNumber][counter / 2].name = row.charAt(counter);
            }else{
                if(row.charAt(counter) == '-') {
                    map[rowNumber][counter / 2].right = true;
                    map[rowNumber][counter / 2 + 1].left = true;
                }
            }
        }
    }

    static void upOrDownWays(Position[][] map, String row, int rowNumber){

        for(int counter = 0; counter < row.length() / 2 + 1; counter++){
            if(row.charAt(counter * 2) == '|'){
                map[(rowNumber - 1) / 2][counter].down = true;
                map[(rowNumber + 1) / 2][counter].up = true;
            }
        }

    }

    static Position[][] getMap(){
        Scanner input = new Scanner(System.in);
        String numberOfRowsAndComumns = input.nextLine();
        int rows = numberOfRowsAndComumns.charAt(0) - 48;
        int column = numberOfRowsAndComumns.charAt(2) - 48;
        int i, j;
        Position[][] map = new Position[(rows / 2) + 1][(column / 2) + 1];
        for (i = 0 ; i < map.length; i++) {
            for (j = 0 ; j < map[0].length; j++) {
                map[i][j] = new Position();
            }
        }
        int rowNumber;
        String rowString;

        for(rowNumber = 0; rowNumber < rows; rowNumber++) {
            rowString = input.nextLine();
            if (rowNumber % 2 == 0) {
                polishRow(map, rowString, rowNumber / 2);
            } else {
                upOrDownWays(map, rowString, rowNumber);
            }
        }

        return map;

    }

}
