import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Person{

    Scanner input = new Scanner(System.in);
    Position place;
    public String direction;
    int sightRange = 1;
    String moveDirection;
    boolean alive = true;

    Person(Position place){
        this.place = place;
    }

    void kill(){}

    void die(){
        alive = false;
    }

    public void move(Position[][] map, int x, int y) {
        boolean end = false;
        for(int i = 0; i < map.length; i++){
            for(int j = 0; j < map[i].length; j++){
                if(map[i][j].name == this.place.name){
                    this.place = map[i + y][j + x];
                    end = true;
                    break;
                }
            }
            if(end){
                break;
            }
        }
    }

    public void moveToLeft(Position[][] map){
        move(map, -1, 0);
    }
    public void moveToRight(Position[][] map){
        move(map, 1, 0);
    }
    public void moveDown(Position[][] map){
        move(map, 0, 1);
    }
    public void moveUp(Position[][] map){
        move(map, 0, -1);
    }

    public int[] indexesOfPosition(Position[][] map, Position place){
        int[] indexes = new int[2];
        for(int i = 0; i < map.length; i++){
            for(int j = 0; j < map[i].length; j++){
                if(map[i][j] == place){
                    indexes[0] = i;
                    indexes[1] = j;
                    return indexes;
                }
            }
        }
        return null;
    }

}

class Hitman extends Person {

    boolean hidden = false;
    int numberOfMoves = 0;
    boolean onTeleport = false;

    Hitman(Position place){
        super(place);
    }

    void hitmanMove(Position[][] map){
        Scanner input = new Scanner(System.in);
        availableMoves();

        do{
            moveDirection = input.next();
            if(moveDirection.equals("Left") && place.left){
                moveToLeft(map);
                numberOfMoves++;
            }else if(moveDirection.equals("Right") && place.right){
                moveToRight(map);
                numberOfMoves++;
            }else if(moveDirection.equals("Down") && place.down){
                moveDown(map);
                numberOfMoves++;
            }else if(moveDirection.equals("Up") && place.up){
                moveUp(map);
                numberOfMoves++;
            }else{
                System.out.println("Unavailable move!");
                continue;
            }
            break;
        }while(true);
    }

    private void availableMoves(){

        System.out.println("Your choice(s) to move:");
        System.out.print(((place.left) ? "Left\n" : ""));
        System.out.print((place.right) ? "Right\n" : "");
        System.out.print((place.up) ? "Up\n" : "");
        System.out.print((place.down) ? "Down\n" : "");

    }

    void kill(ArrayList<Person> listOfPersons){

        int numberOfKills = 0;
        Iterator<Person> itr = listOfPersons.iterator();
        while(itr.hasNext()){
            Person person = (Person)itr.next();
            if(this.place == person.place && !(person instanceof Hitman)){
                person.alive = false;
                numberOfKills++;
            }
        }
        if(numberOfKills > 0) {
            System.out.println("You've killed " + numberOfKills + " enemy in this move!");
        }
    }

}

class Enemy extends Person {

    boolean alert = false;

    public Enemy(Position place) {
        super(place);
    }


    public void kill(Hitman hitman, Position[][] map) {
        int[] indexes = indexesOfPosition(map, place);

        if (direction.equals("Left") && this.place.left && !hitman.hidden) {
            if(hitman.place == map[indexes[0]][indexes[1] - 1] ) {
                moveToLeft(map);
                hitman.alive = false;
            }
        } else if (direction.equals("Right") && this.place.right && !hitman.hidden) {
            if(hitman.place == map[indexes[0]][indexes[1] + 1] ) {
                moveToRight(map);
                hitman.alive = false;
            }
        } else if (direction.equals("Down") && this.place.down && !hitman.hidden) {
            if(hitman.place == map[indexes[0] + 1][indexes[1]] ) {
                moveDown(map);
                hitman.alive = false;
            }
        } else if (direction.equals("Up") && this.place.up && !hitman.hidden  ) {
            if(hitman.place == map[indexes[0] - 1][indexes[1]]) {
                moveUp(map);
                hitman.alive = false;
            }
        }
    }

    public void beingAlert(Position map[][]){
        //write the tools class first
    }

    void changeDirection(){
        if(this.direction.equals("Left")){
            this.direction = "Right";
        }else if(this.direction.equals("Right")){
            this.direction = "Left";
        }else if(this.direction.equals("Up")){
            this.direction = "Down";
        }else if(this.direction.equals("Down")){
            this.direction = "Up";
        }
    }

}

class StaticEnemy extends Enemy{
    StaticEnemy(Position place){
        super(place);
    }
}

class DynamicEnemy extends Enemy{

    DynamicEnemy(Position place){
        super(place);
    }

    public void move(Position[][] map){
        if (this.direction.equals("Left")){
            if(this.place.left) {
                moveToLeft(map);
            }else{
                changeDirection();
                moveToRight(map);
            }
        }else if(this.direction.equals("Right")){
            if(this.place.right){
                moveToRight(map);
            }else{
                changeDirection();
                moveToLeft(map);
            }
        }else if(this.direction.equals("Up")){
            if(this.place.up){
                moveUp(map);
            }else{
                changeDirection();
                moveDown(map);
            }
        }else if(this.direction.equals("Down")){
            if(this.place.down){
                moveDown(map);
            }else{
                changeDirection();
                moveUp(map);
            }
        }
    }

}

class SpinicEnemy extends Enemy{

    public SpinicEnemy(Position place) {
        super(place);
    }

}

class SmellicEnemy extends Enemy{
    SmellicEnemy(Position place){
        super(place);
    }

    public void kill(Hitman hitman, Position[][] map) {
        if (direction.equals("Left") && hitman.place.right) {
            moveToLeft(map);
            hitman.alive = false;
        } else if (direction.equals("Right") && hitman.place.left) {
            moveToRight(map);
            hitman.alive = false;
        } else if (direction.equals("Down") && hitman.place.up) {
            moveDown(map);
            hitman.alive = false;
        } else if (direction.equals("Up") && hitman.place.down) {
            moveUp(map);
            hitman.alive = false;
        }
    }

    public void dogBeingAlert(Hitman hitman, Position[][] map){

    }
}
