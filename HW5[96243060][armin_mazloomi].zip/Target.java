public class Target {
    Position place;
    boolean done = false;

    void win(Hitman hitman){
        if(hitman.place == this.place){
            done = true;
        }
    }
}
