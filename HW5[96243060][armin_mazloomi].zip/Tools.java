import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Tools{
    Scanner input = new Scanner(System.in);
    Position place;
    boolean used = false;

    Tools(Position place){
        this.place = place;
    }

    public int[] indexesOfPosition(Position[][] map, Position place){
        int[] indexes = new int[2];
        for(int i = 0; i < map.length; i++){
            for(int j = 0; j < map[i].length; j++){
                if(map[i][j] == place){
                    indexes[0] = i;
                    indexes[1] = j;
                    return indexes;
                }
            }
        }
        return null;
    }
}

class Stone extends Tools{


    boolean left = true, right = true, up = true, down = true;

    Stone(Position place){
        super(place);
    }

    public void throwStone(Position[][] map){
        if(!used) {
            availableThrows(map);
            String throwDirection = input.next();
            int[] indexes = indexesOfPosition(map, this.place);

            while (true) {
                if (throwDirection.equals("Left") && left && !used) {
                    distract(map, map[indexes[0] - 1][indexes[1]]);
                } else if (throwDirection.equals("Right") && right && !used) {
                    distract(map, map[indexes[0] + 1][indexes[1]]);
                } else if (throwDirection.equals("Up") && up && !used) {
                    distract(map, map[indexes[0]][indexes[1] - 1]);
                } else if (throwDirection.equals("Down") && down && !used) {
                    distract(map, map[indexes[0]][indexes[1] + 1]);
                } else {
                    System.out.println("Unavailable throw!");
                    System.out.println("Choose the throw direction again : ");
                    continue;
                }
                used = true;
                break;
            }
        }
    }

    private void availableThrows(Position[][] map){
        System.out.println("Your choices to throw the stone:");
        int[] indexes = indexesOfPosition(map, this.place);
        left = (indexes[0] - 1 >= 0);
        right = (indexes[0] + 1 < map[indexes[0]].length);
        up = (indexes[1] - 1 >= 0);
        down = (indexes[1] + 1 < map.length);

        //Printing the available throws for the user
        System.out.print(left ? "Left, " : "");
        System.out.print(right ? "Right, " : "");
        System.out.print(up ? "Up, " : "");
        System.out.print(down ? "Down.\n" : "");
    }

    private void distract(Position[][] map, Position placeOfThrownStone){
        //Write when you learn the given code
    }
}

class Snipe extends Tools{
    char target;

    Snipe(Position place){
        super(place);
    }

    void chooseTarget(){
        System.out.println("Enter the place you want to shoot: ");
        target = input.next().charAt(0);
    }

    void shoot(ArrayList<Person> person, Hitman hitman){
        if(!used) {
            int deadCounts = 0;
            chooseTarget();
            Iterator itr = person.iterator();
            while (itr.hasNext()) {
                Person man = (Person) itr.next();
                if (target == man.place.name) {
                    man.die();
                    deadCounts++;
                }
            }
            used = true;
            System.out.println("You've killed " + deadCounts + " enemies with this shot.");
        }
    }
}

class Pot extends Tools{

    Pot(Position place){
        super(place);
    }

    void hidingInpot(Hitman hitman){
        if(this.place == hitman.place){
            hitman.hidden = true;
        }else{
            hitman.hidden = false;
        }
    }

}

class TelePort extends Tools{

    TelePort(Position place){
        super(place);
    }

    void telePorting(Hitman hitman, TelePort telePortPair){
        if(this.place == hitman.place){
            hitman.place = telePortPair.place;
            hitman.numberOfMoves++;
        }
    }

}

class Camera extends Tools{

    Camera(Position place){
        super(place);
    }

    void alertingEnemies(Hitman hitman){
        if(hitman.place == this.place){
            //Complete when you learned the given code
        }
    }
}