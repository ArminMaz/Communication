import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Position {
    char name;
    boolean right = false, left = false, up = false, down = false;

}

